from flask import Flask, request, render_template
import requests

# for csrf
from bs4 import BeautifulSoup
# robots.txt
from urllib.parse import urlparse, urljoin

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

# -------------------------------------new 2 all--------------------

@app.route('/scan', methods=['POST'])
def scan():
    url = request.form['url']
    if not url.startswith('http'):
        url = 'http://' + url

    results = {
        'xss': check_xss(url),
        'sql': check_sql_injection(url),
        'csrf': check_csrf(url),
        'robots': analyze_robots(url),
        'security_headers': check_security_headers(url),
        'open_redirect': check_for_open_redirect(url),
        'directory_enumeration': check_for_directory_enumeration(url)
    }
    return render_template('result.html', url=url, results=results)

def check_xss(url):
    test_script = "<script>alert('XSS');</script>"
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')
        forms = soup.find_all('form')
        xss_vulnerable_forms = []
        for form in forms:
            form_action = form.get('action')
            form_method = form.get('method', 'get').lower()
            inputs = form.find_all('input')
            form_data = {}
            for input_tag in inputs:
                input_name = input_tag.get('name')
                input_type = input_tag.get('type', 'text')
                if input_name:
                    if input_type == 'text':
                        form_data[input_name] = test_script
                    else:
                        form_data[input_name] = 'test'
            if form_action:
                action_url = urljoin(url, form_action)
            else:
                action_url = url
            if form_method == 'post':
                response = requests.post(action_url, data=form_data)
            else:
                response = requests.get(action_url, params=form_data)
            if test_script in response.text:
                xss_vulnerable_forms.append(action_url)
        return xss_vulnerable_forms
    except requests.RequestException:
        return []

def check_sql_injection(url):
    test_sql = "' OR '1'='1"
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')
        forms = soup.find_all('form')
        sql_vulnerable_forms = []
        for form in forms:
            form_action = form.get('action')
            form_method = form.get('method', 'get').lower()
            inputs = form.find_all('input')
            form_data = {}
            for input_tag in inputs:
                input_name = input_tag.get('name')
                input_type = input_tag.get('type', 'text')
                if input_name:
                    if input_type == 'text':
                        form_data[input_name] = test_sql
                    else:
                        form_data[input_name] = 'test'
            if form_action:
                action_url = urljoin(url, form_action)
            else:
                action_url = url
            if form_method == 'post':
                response = requests.post(action_url, data=form_data)
            else:
                response = requests.get(action_url, params=form_data)
            if "mysql" in response.text.lower() or "syntax error" in response.text.lower():
                sql_vulnerable_forms.append(action_url)
        return sql_vulnerable_forms
    except requests.RequestException:
        return []

def check_csrf(url):
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')
        forms = soup.find_all('form')
        csrf_vulnerable_forms = []
        for form in forms:
            inputs = form.find_all('input')
            has_csrf_token = any('csrf' in input_tag.get('name', '').lower() for input_tag in inputs)
            if not has_csrf_token:
                csrf_vulnerable_forms.append(form)
        return csrf_vulnerable_forms
    except requests.RequestException:
        return []

def analyze_robots(url):
    robots_url = url + '/robots.txt'
    try:
        response = requests.get(robots_url)
        response.raise_for_status()
        robots_content = response.text
        interesting_urls = []
        for line in robots_content.split('\n'):
            if line.strip().lower().startswith('disallow'):
                parts = line.split(':')
                if len(parts) > 1:
                    path = parts[1].strip()
                    if path:
                        interesting_urls.append(urljoin(url, path))
        return interesting_urls
    except requests.RequestException:
        return []

def check_security_headers(url):
    headers_to_check = {
        'Content-Security-Policy': 'The Content-Security-Policy (CSP) header helps to protect against Cross-Site Scripting (XSS) and other attacks. It allows you to define which dynamic resources are allowed to load.',
        'X-Content-Type-Options': 'The X-Content-Type-Options header prevents browsers from interpreting files as a different MIME type than what is specified in the Content-Type header.',
        'X-Frame-Options': 'The X-Frame-Options header protects against Clickjacking attacks by controlling whether the browser should allow a page to be displayed in an iframe.',
        'Strict-Transport-Security': 'The Strict-Transport-Security header ensures that browsers only connect to your site using HTTPS.',
        'X-XSS-Protection': 'The X-XSS-Protection header enables the cross-site scripting (XSS) filter built into most browsers.',
        'Referrer-Policy': 'The Referrer-Policy header controls how much referrer information should be included with requests.'
    }
    missing_headers = {}
    try:
        response = requests.get(url)
        for header, description in headers_to_check.items():
            if header not in response.headers:
                missing_headers[header] = description
        return missing_headers
    except requests.RequestException:
        return {}

def check_for_open_redirect(url):
    test_redirect = 'http://example.com'
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')
        forms = soup.find_all('form')
        open_redirect_vulnerable_forms = []
        for form in forms:
            form_action = form.get('action')
            form_method = form.get('method', 'get').lower()
            inputs = form.find_all('input')
            form_data = {}
            for input_tag in inputs:
                input_name = input_tag.get('name')
                if input_name and 'url' in input_name.lower():
                    form_data[input_name] = test_redirect
            if form_data:
                if form_action:
                    action_url = urljoin(url, form_action)
                else:
                    action_url = url
                if form_method == 'post':
                    response = requests.post(action_url, data=form_data, allow_redirects=False)
                else:
                    response = requests.get(action_url, params=form_data, allow_redirects=False)
                if response.status_code in (301, 302) and response.headers.get('Location') == test_redirect:
                    open_redirect_vulnerable_forms.append(action_url)
        return open_redirect_vulnerable_forms
    except requests.RequestException:
        return []

def check_for_directory_enumeration(url):
    common_directories = [
        'admin/', 'backup/', 'config/', 'db/', 'includes/', 'uploads/', 'logs/'
    ]
    directory_enumeration_vulnerabilities = []
    for directory in common_directories:
        check_url = urljoin(url, directory)
        try:
            response = requests.get(check_url)
            if response.status_code == 200:
                directory_enumeration_vulnerabilities.append(check_url)
        except requests.RequestException:
            continue
    return directory_enumeration_vulnerabilities

# ------------------------------------new 1 all---------------------

# @app.route('/scan', methods=['POST'])
# def scan():
#     url = request.form['url']
#     if not url.startswith('http'):
#         url = 'http://' + url

#     results = {
#         'xss': check_xss(url),
#         'sql': check_sql_injection(url),
#         'csrf': check_csrf(url),
#         'robots': analyze_robots(url)
#     }
#     return render_template('result.html', url=url, results=results)

# def check_xss(url):
#     # Basic XSS check by injecting script tags into parameters
#     test_script = "<script>alert('XSS');</script>"
#     try:
#         response = requests.get(url)
#         soup = BeautifulSoup(response.text, 'html.parser')
#         forms = soup.find_all('form')
#         xss_vulnerable_forms = []
#         for form in forms:
#             form_action = form.get('action')
#             form_method = form.get('method', 'get').lower()
#             inputs = form.find_all('input')
#             form_data = {}
#             for input_tag in inputs:
#                 input_name = input_tag.get('name')
#                 input_type = input_tag.get('type', 'text')
#                 if input_name:
#                     if input_type == 'text':
#                         form_data[input_name] = test_script
#                     else:
#                         form_data[input_name] = 'test'
#             if form_action:
#                 action_url = urljoin(url, form_action)
#             else:
#                 action_url = url
#             if form_method == 'post':
#                 response = requests.post(action_url, data=form_data)
#             else:
#                 response = requests.get(action_url, params=form_data)
#             if test_script in response.text:
#                 xss_vulnerable_forms.append(action_url)
#         return xss_vulnerable_forms
#     except requests.RequestException:
#         return []

# def check_sql_injection(url):
#     # Basic SQL Injection check by injecting SQL syntax into parameters
#     test_sql = "' OR '1'='1"
#     try:
#         response = requests.get(url)
#         soup = BeautifulSoup(response.text, 'html.parser')
#         forms = soup.find_all('form')
#         sql_vulnerable_forms = []
#         for form in forms:
#             form_action = form.get('action')
#             form_method = form.get('method', 'get').lower()
#             inputs = form.find_all('input')
#             form_data = {}
#             for input_tag in inputs:
#                 input_name = input_tag.get('name')
#                 input_type = input_tag.get('type', 'text')
#                 if input_name:
#                     if input_type == 'text':
#                         form_data[input_name] = test_sql
#                     else:
#                         form_data[input_name] = 'test'
#             if form_action:
#                 action_url = urljoin(url, form_action)
#             else:
#                 action_url = url
#             if form_method == 'post':
#                 response = requests.post(action_url, data=form_data)
#             else:
#                 response = requests.get(action_url, params=form_data)
#             if "mysql" in response.text.lower() or "syntax error" in response.text.lower():
#                 sql_vulnerable_forms.append(action_url)
#         return sql_vulnerable_forms
#     except requests.RequestException:
#         return []

# def check_csrf(url):
#     # Basic CSRF check by looking for missing CSRF tokens in forms
#     try:
#         response = requests.get(url)
#         soup = BeautifulSoup(response.text, 'html.parser')
#         forms = soup.find_all('form')
#         csrf_vulnerable_forms = []
#         for form in forms:
#             inputs = form.find_all('input')
#             has_csrf_token = any('csrf' in input_tag.get('name', '').lower() for input_tag in inputs)
#             if not has_csrf_token:
#                 csrf_vulnerable_forms.append(form)
#         return csrf_vulnerable_forms
#     except requests.RequestException:
#         return []

# def analyze_robots(url):
#     robots_url = url + '/robots.txt'
#     try:
#         response = requests.get(robots_url)
#         response.raise_for_status()
#         robots_content = response.text
#         interesting_urls = []
#         for line in robots_content.split('\n'):
#             if line.strip().lower().startswith('disallow'):
#                 parts = line.split(':')
#                 if len(parts) > 1:
#                     path = parts[1].strip()
#                     if path:
#                         interesting_urls.append(urljoin(url, path))
#         return interesting_urls
#     except requests.RequestException:
#         return []
    

# def check_for_open_redirect(url):
#     payloads = ["?redirect=https://evil.com", "?url=https://evil.com"]
#     open_redirect_vulnerabilities = []
#     for payload in payloads:
#         try:
#             test_url = url + payload
#             response = requests.get(test_url)
#             if response.url != test_url:
#                 open_redirect_vulnerabilities.append(payload)
#         except requests.RequestException:
#             continue
#     return open_redirect_vulnerabilities

# def check_for_directory_enumeration(url):
#     common_paths = ["/admin", "/backup", "/config", "/hidden"]
#     directories_found = []
#     for path in common_paths:
#         try:
#             test_url = url + path
#             response = requests.get(test_url)
#             if response.status_code == 200:
#                 directories_found.append(path)
#         except requests.RequestException:
#             continue
#     return directories_found
    


# -------------------------------------old ALL------------------------

# @app.route('/scan', methods=['POST'])
# def scan():
#     url = request.form['url']
#     # robot.txt see
#     if not url.startswith('http'):
#         url = 'http://' + url
    
#     robots_url = url + '/robots.txt'
#     # -------
#     xss_vulnerabilities = check_for_xss(url)
#     sql_vulnerabilities = check_for_sql_injection(url)
#     csrf_vulnerabilities = check_for_csrf(url)
#     # ---
#     try:
#         response = requests.get(robots_url)
#         response.raise_for_status()
#         robots_content = response.text
#         interesting_urls = analyze_robots(robots_content)
#         return render_template('result.html', 
#                                url=url, 
#                                robots_content=robots_content, 
#                                interesting_urls=interesting_urls, 
#                                xss_vulnerabilities=xss_vulnerabilities, 
#                                sql_vulnerabilities=sql_vulnerabilities, 
#                                csrf_vulnerabilities=csrf_vulnerabilities)
#     except requests.exceptions.RequestException as e:
#         return render_template('result.html', url=url, error=str(e))
    
#     # return render_template('result.html', 
#     #                        xss_vulnerabilities=xss_vulnerabilities, 
#     #                        sql_vulnerabilities=sql_vulnerabilities, 
#     #                        csrf_vulnerabilities=csrf_vulnerabilities)

# def analyze_robots(content):
#     lines = content.split('\n')
#     interesting_urls = []
#     for line in lines:
#         if line.strip().lower().startswith('disallow'):
#             parts = line.split(':')
#             if len(parts) > 1:
#                 path = parts[1].strip()
#                 if path:
#                     interesting_urls.append(path)
#     return interesting_urls

# def check_for_xss(url):
#     payloads = ["<script>alert('XSS')</script>", "<img src=x onerror=alert(1)>"]
#     # vulnerabilities = []
#     xss_vulnerabilities = []
#     for payload in payloads:
#         try:
#             response = requests.get(url + payload)
#             if payload in response.text:
#                 # vulnerabilities.append(payload)
#                 xss_vulnerabilities.append(payload)
#         except requests.RequestException:
#             continue
#     # return vulnerabilities
#     return xss_vulnerabilities

# def check_for_sql_injection(url):
#     payloads = ["' OR '1'='1", "' OR '1'='1' -- ", "' OR '1'='1' /*", "' OR 'x'='x'"]
#     # vulnerabilities = []
#     sql_vulnerabilities = []
#     for payload in payloads:
#         try:
#             test_url = url + payload
#             response = requests.get(test_url)
#             if "error" in response.text.lower() or "sql" in response.text.lower():
#                 # vulnerabilities.append(payload)
#                 sql_vulnerabilities.append(payload)
#         except requests.RequestException:
#             continue
#     # return vulnerabilities
#     return sql_vulnerabilities

# def check_for_csrf(url):
#     try:
#         response = requests.get(url)
#         soup = BeautifulSoup(response.text, 'html.parser')
#         forms = soup.find_all('form')
#         csrf_vulnerable_forms = []
#         for form in forms:
#             has_token = any(input_tag.get('name', '').lower() in ('csrf_token', 'authenticity_token', 'xsrf_token')
#                             for input_tag in form.find_all('input'))
#             if not has_token:
#                 csrf_vulnerable_forms.append(str(form))

#         security_headers = {
#             'X-Frame-Options': response.headers.get('X-Frame-Options', None),
#             'X-Content-Type-Options': response.headers.get('X-Content-Type-Options', None),
#             'X-XSS-Protection': response.headers.get('X-XSS-Protection', None)
#         }

#         # vulnerabilities = {
#         csrf_vulnerabilities = {
#             'csrf_vulnerable_forms': csrf_vulnerable_forms,
#             'missing_security_headers': {k: v for k, v in security_headers.items() if not v}
#         }
#     except requests.RequestException:
#         # vulnerabilities = {
#         csrf_vulnerabilities = {
#             'csrf_vulnerable_forms': [],
#             'missing_security_headers': {}
#         }
    
#     # return vulnerabilities
#     return csrf_vulnerabilities

# --------------------------------------------------

# -----------code their

# -----------------------------------------XSS-----------------------------

# @app.route('/scan', methods=['POST'])
# def scan():
#     url = request.form['url']
#     vulnerabilities = check_for_xss(url)
#     return render_template('result.html', vulnerabilities=vulnerabilities)

# def check_for_xss(url):
#     payloads = ["<script>alert('XSS')</script>", "<img src=x onerror=alert(1)>"]
#     vulnerabilities = []
#     for payload in payloads:
#         response = requests.get(url + payload)
#         if payload in response.text:
#             vulnerabilities.append(payload)
#     return vulnerabilities

# -----------------------------------------------------------------------------
# ----------------------SQL INJECTION---------------------------

# @app.route('/scan', methods=['POST'])
# def scan():
#     url = request.form['url']
#     vulnerabilities = check_for_sql_injection(url)
#     return render_template('result.html', vulnerabilities=vulnerabilities)

# def check_for_sql_injection(url):
#     payloads = ["' OR '1'='1", "' OR '1'='1' -- ", "' OR '1'='1' /*", "' OR 'x'='x'"]
#     vulnerabilities = []
#     for payload in payloads:
#         test_url = url + payload
#         response = requests.get(test_url)
#         if "error" in response.text.lower() or "sql" in response.text.lower():
#             vulnerabilities.append(payload)
#     return vulnerabilities

# -------------------------------------------------------------------------
# ----------------------CSRF----------------------------------

# @app.route('/scan', methods=['POST'])
# def scan():
#     url = request.form['url']
#     vulnerabilities = check_for_csrf(url)
#     return render_template('result.html', vulnerabilities=vulnerabilities)

# def check_for_csrf(url):
#     response = requests.get(url)
#     soup = BeautifulSoup(response.text, 'html.parser')

#     forms = soup.find_all('form')
#     csrf_vulnerable_forms = []

#     for form in forms:
#         has_token = any(input_tag.get('name', '').lower() in ('csrf_token', 'authenticity_token', 'xsrf_token')
#                         for input_tag in form.find_all('input'))
#         if not has_token:
#             csrf_vulnerable_forms.append(str(form))

#     security_headers = {
#         'X-Frame-Options': response.headers.get('X-Frame-Options', None),
#         'X-Content-Type-Options': response.headers.get('X-Content-Type-Options', None),
#         'X-XSS-Protection': response.headers.get('X-XSS-Protection', None)
#     }

#     vulnerabilities = {
#         'csrf_vulnerable_forms': csrf_vulnerable_forms,
#         'missing_security_headers': {k: v for k, v in security_headers.items() if not v}
#     }

#     return vulnerabilities

if __name__ == '__main__':
    app.run(debug=True)

